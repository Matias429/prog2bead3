#include "widget.h"
#include "amobawid.h"
#include "graphics.hpp"
#include "gamemaster.h"
#include <cmath>

using namespace genv;
using namespace std;

void Jatek::mezovalt(double ex, double ey, int r)
{
    int o = floor(ex/X*15);
    int s = floor(ey/Y*15);
    if ((r == 1 && player == false) || (r == 2 && player == true))
    {
        this->board[o][s]->action(r);
        this->board[o][s]->draw();
        if (this->player == false)
        {
            this->player = true;
        }
        else
        {
            this->player = false;
        }
    }
}
void Jatek::cclear()
{
    gout << move_to(0, 0) << color(0, 0, 0) << box(X, Y);
}
void Jatek::feltolt(vector<Amoba*> oszlop)
{
    board.push_back(oszlop);
}
vector<vector<Amoba*>> Jatek::boardstate()
{
    return board;
}
