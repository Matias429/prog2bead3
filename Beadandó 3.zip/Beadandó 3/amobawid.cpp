#include "widget.h"
#include "amobawid.h"
#include "graphics.hpp"

using namespace genv;

Amoba::Amoba(double ex, double ey, double six, double siy)
{
    x = ex;
    y = ey;
    size_x = six;
    size_y = siy;
}
void Amoba::draw()
{
    gout << move_to(x, y) << color(160, 160, 160) << box(size_x, size_y);
    if (ertek == 0)
    {
        gout << move_to(x+size_x/10, y+size_y/10) << color(240, 240, 240) << box(0.8*size_x, 0.8*size_y);
    }
    else if (ertek == 1)
    {
        gout << move_to(x+size_x/10, y+size_y/10) << color(255, 0, 0) << box(0.8*size_x, 0.8*size_y);
    }
    else if (ertek == 2)
    {
        gout << move_to(x+size_x/10, y+size_y/10) << color(0, 255, 0) << box(0.8*size_x, 0.8*size_y);
    }
    gout << refresh;
}
void Amoba::action(int uj)
{
    ertek = uj;
}
int Amoba::ertekret()
{
    return ertek;
}
