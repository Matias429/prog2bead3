#include "gamemaster.h"

int main()
{
    srand (time(NULL));
    gout.open(X,Y);
    Jatek *jatekmester = new Jatek;
    for (size_t i = 0; i < 15; i++)
    {
        vector<Amoba*> oszlop;
        for (size_t j = 0; j < 15; j++)
        {
            Amoba *mezo = new Amoba(i*X/15, j*Y/15, X/15, Y/15);
            mezo->draw();
            oszlop.push_back(mezo);
        }
        jatekmester->feltolt(oszlop);
    }
    event ev;
    while(gin >> ev && ev.keycode != key_escape)
    {
        if (ev.type == ev_mouse)
        {
            if (ev.button == btn_left)
            {
                jatekmester->mezovalt(ev.pos_x, ev.pos_y, 1);
            }
            else if (ev.button == btn_right)
            {
                jatekmester->mezovalt(ev.pos_x, ev.pos_y, 2);
            }
        }
    }
    return 0;
}
