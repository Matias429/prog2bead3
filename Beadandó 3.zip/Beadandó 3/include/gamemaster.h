#ifndef GAMEMASTER_H_INCLUDED
#define GAMEMASTER_H_INCLUDED

#include "graphics.hpp"
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <time.h>
#include <vector>
#include "amobawid.h"

using namespace genv;
using namespace std;

class Jatek
{
private:
    bool player, menu, pvp, endgame;
    vector<vector<Amoba*>> board;
public:
    void valaszt();
    void mezovalt(double ex, double ey, int r);
    void cclear();
    void feltolt(vector<Amoba*> oszlop);
    vector<vector<Amoba*>> boardstate();
};



#endif // GAMEMASTER_H_INCLUDED
