#ifndef WIDGET_H_INCLUDED
#define WIDGET_H_INCLUDED

const int X=990;
const int Y=990;

class Widget
{
protected:
    double x, y, size_x, size_y, ox, oy, clickx, clicky;
    bool active = false;
public:
    virtual void Activator(double ex, double ey);
    void DeActivator();
    bool ActiveGetter();
    virtual void movement(double ex, double ey);
};


#endif // WIDGET_H_INCLUDED
