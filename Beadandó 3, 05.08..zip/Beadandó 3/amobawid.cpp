#include "widget.h"
#include "amobawid.h"
#include "graphics.hpp"

Amoba::Amoba(double ex, double ey, double six, double siy)
{
    x = ex;
    y = ey;
    size_x = six;
    size_y = siy;
}
void Amoba::draw()
{
    genv::gout << genv::move_to(x, y) << genv::color(160, 160, 160) << genv::box(size_x, size_y);
    if (ertek == 0)
    {
        genv::gout << genv::move_to(x+size_x/10, y+size_y/10) << genv::color(240, 240, 240) << genv::box(0.8*size_x, 0.8*size_y);
    }
    else if (ertek == 1)
    {
        genv::gout << genv::move_to(x+size_x/10, y+size_y/10) << genv::color(255, 0, 0) << genv::box(0.8*size_x, 0.8*size_y);
    }
    else if (ertek == 2)
    {
        genv::gout << genv::move_to(x+size_x/10, y+size_y/10) << genv::color(0, 255, 0) << genv::box(0.8*size_x, 0.8*size_y);
    }
    genv::gout << genv::refresh;
}
void Amoba::action(int uj)
{
    ertek = uj;
}
int Amoba::ertekret()
{
    return ertek;
}
void Amoba::reset()
{
    ertek = 0;
}
