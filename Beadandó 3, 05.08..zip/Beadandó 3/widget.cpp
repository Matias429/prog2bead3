#include "widget.h"

void Widget::Activator(double ex, double ey)
{
    if (x < ex && ex < x+size_x && y < ey && ey < y+size_y && active == false)
    {
        active = true;
        clickx = ex;
        clicky = ey;
        ox = x;
        oy = y;
    }
}
void Widget::movement(double ex, double ey)
{
    if (size_y/3 < ox+ex-clickx && ox+ex-clickx < X-size_x/2-size_y/3 && 50 < oy+ey-clicky && oy+ey-clicky < Y-size_y/2-50)
    {
        x = ox+ex-clickx;
        y = oy+ey-clicky;
    }
}
bool Widget::ActiveGetter()
{
    return active;
}
void Widget::DeActivator()
{
    active = false;
}
