#include "gamemaster.h"

using namespace std;
using namespace genv;

void feliratok(vector<string> &szovegek1, vector<string> &szovegek2)
{
    szovegek1.push_back("PvP"); szovegek1.push_back("PvE");szovegek1.push_back("Play");
    szovegek2.push_back("Main Menu"); szovegek2.push_back("Play Again");szovegek2.push_back("Exit");
}

int main()
{
    vector<string> menufeliratok;
    vector<string> endfeliratok;
    feliratok(menufeliratok, endfeliratok);
    Jatek *jatekmester = new Jatek;
    jatekmester->open();
    for (size_t i = 0; i < 3; i++)
    {
        Gomb *button = new Gomb(menufeliratok[i], X/3, Y/3+i*Y/6-Y/16, X/3, Y/8);
        jatekmester->menufeltolt(button, 1);
        Gomb *button2 = new Gomb(endfeliratok[i], X/3, Y/3+i*Y/6-Y/16, X/3, Y/8);
        jatekmester->menufeltolt(button2, 2);
    }
    for (size_t i = 0; i < 15; i++)
    {
        vector<Amoba*> oszlop;
        for (size_t j = 0; j < 15; j++)
        {
            Amoba *mezo = new Amoba(i*X/15, j*Y/15, X/15, Y/15);
            oszlop.push_back(mezo);
        }
        jatekmester->feltolt(oszlop);
    }
    event ev;
    while(gin >> ev && ev.keycode != key_escape)
    {
        if (jatekmester->menuret() || jatekmester->endgameret())
        {
            jatekmester->menudraw();
            if (ev.type == ev_mouse && ev.button == -btn_left && jatekmester->menuret())
            {
                jatekmester->mainclick(ev.pos_x, ev.pos_y);
            }
            else if (ev.type == ev_mouse && ev.button == btn_left && jatekmester->endgameret())
            {
                jatekmester->endclick(ev.pos_x, ev.pos_y);
            }
        }
        if (!jatekmester->menuret() && !jatekmester->endgameret())
        {
            if (ev.type == ev_mouse)
            {
                if (ev.button == btn_left)
                {
                    jatekmester->mezovalt(ev.pos_x, ev.pos_y, 1);
                }
                else if (ev.button == btn_right)
                {
                    jatekmester->mezovalt(ev.pos_x, ev.pos_y, 2);
                }
            }
        }
    }
    return 0;
}
