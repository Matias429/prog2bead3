#include "widget.h"
#include "amobawid.h"
#include "graphics.hpp"
#include "gamemaster.h"
#include <cmath>

void Jatek::wincheck(int k, int l, int e)
{
    bool check1 = true;
    bool check2 = true;
    for (int i = -1; i < 2; i++)
    {
        int mellett = 1;
        int lepes = 1;
        while (check1 == true)
        {
            if (board[k-1][l]->ertekret() == e || board[k+1][l]->ertekret() == e)
            {
                if (k-lepes >= 0 && k+lepes < 15 && board[k+lepes][l]->ertekret() == e)
                {
                    mellett++;
                    lepes++;
                }
                else
                {
                    check1 = false;
                    lepes = 1;
                }
            }
            else if (k+i*lepes >= 0 && k+i*lepes < 15 && l-lepes >= 0 && l-lepes < 15 && board[k+i*lepes][l-lepes]->ertekret() == e)
            {
                mellett++;
                lepes++;
            }
            else
            {
                check1 = false;
                lepes = 1;
            }
        }
        while (check2 == true)
        {
            if (board[k-1][l]->ertekret() == e || board[k+1][l]->ertekret() == e)
            {
                if (k-lepes >= 0 && k+lepes < 15 && board[k-lepes][l]->ertekret() == e)
                {
                    mellett++;
                    lepes++;
                }
                else
                {
                    check2 = false;
                    lepes = 1;
                }
            }
            else if (k-i*lepes >= 0 && k-i*lepes < 15 && l+lepes >= 0 && l+lepes < 15 && board[k-i*lepes][l+lepes]->ertekret() == e)
            {
                mellett++;
                lepes++;
            }
            else
            {
                check2 = false;
                lepes = 1;
            }
        }
        if (mellett >= 5)
        {
            endgame = true;
        }
        check1 = true;
        check2 = true;
    }
}
void Jatek::mezovalt(double ex, double ey, int r)
{
    int o = floor(ex/X*15);
    int s = floor(ey/Y*15);
    if (((r == 1 && player == true ) || (r == 2 && player == false)) && board[o][s]->ertekret() == 0)
    {
        board[o][s]->action(r);
        board[o][s]->draw();
        szabadmezok--;
        if (player == true)
        {
            player = false;
            wincheck(o, s, 1);
        }
        else
        {
            player = true;
            wincheck(o, s, 2);
        }
        if (szabadmezok == 0)
        {
            endgame = true;
        }
    }
}
void Jatek::cclear()
{
    genv::gout << genv::move_to(0, 0) << genv::color(0, 0, 0) << genv::box(X, Y);
}
void Jatek::feltolt(std::vector<Amoba*> oszlop)
{
    board.push_back(oszlop);
}
void Jatek::menudraw()
{
    if (menu == true)
    {
        for (size_t i = 0; i < mainmenu.size(); i++)
        {
            mainmenu[i]->draw();
        }
    }
    else if (endgame == true)
    {
        for (size_t i = 0; i < endmenu.size(); i++)
        {
            endmenu[i]->draw();
        }
    }
    genv::gout << genv::refresh;
}
bool Jatek::menuret()
{
    return menu;
}
bool Jatek::endgameret()
{
    return endgame;
}
void Jatek::open()
{
    genv::gout.open(X,Y);
}
void Jatek::gamestart()
{
    cclear();
    szabadmezok = 225;
    for (size_t i = 0; i < 15; i++)
    {
        for (size_t j = 0; j < 15; j++)
        {
            board[i][j]->reset();
            board[i][j]->draw();
        }
    }
    genv::gout << genv::refresh;
    player = true;
}
void Jatek::menufeltolt(Gomb *button, int r)
{
    if (r == 1)
    {
        mainmenu.push_back(button);
    }
    else
    {
        endmenu.push_back(button);
    }
}
void Jatek::mainclick(double ex, double ey)
{
    std::vector<std::vector<double>> tmp;
    for (size_t i = 0; i < 3; i++)
    {
        tmp.push_back(mainmenu[i]->koordret());
    }
    if (tmp[0][0] < ex && ex < tmp[0][0]+tmp[0][2] && tmp[0][1] < ey && ey < tmp[0][1]+tmp[0][3])
    {
        pvp = true;
    }
    if (tmp[1][0] < ex && ex < tmp[1][0]+tmp[1][2] && tmp[1][1] < ey && ey < tmp[1][1]+tmp[1][3])
    {
        pvp = false;
    }
    if (tmp[2][0] <= ex && ex <= tmp[2][0]+tmp[2][2] && tmp[2][1] <= ey && ey <= tmp[2][1]+tmp[2][3])
    {
        menu = false;
        this->gamestart();
    }
}
void Jatek::endclick(double ex, double ey)
{
    std::vector<std::vector<double>> tmp;
    for (size_t i = 0; i < 3; i++)
    {
        tmp.push_back(endmenu[i]->koordret());
    }
    if (tmp[0][0] < ex && ex < tmp[0][0]+tmp[0][2] && tmp[0][1] < ey && ey < tmp[0][1]+tmp[0][3])
    {
        menu = true;
        endgame = false;
    }
    if (tmp[1][0] < ex && ex < tmp[1][0]+tmp[1][2] && tmp[1][1] < ey && ey < tmp[1][1]+tmp[1][3])
    {
        gamestart();
        endgame = false;
    }
    if (tmp[2][0] <= ex && ex <= tmp[2][0]+tmp[2][2] && tmp[2][1] <= ey && ey <= tmp[2][1]+tmp[2][3])
    {
        exit(1);
    }
}
