#ifndef AMOBA_H_INCLUDED
#define AMOBA_H_INCLUDED

#include "widget.h"
#include <string>

class Amoba : public Widget
{
private:
    int ertek = 0;
public:
    Amoba(double ex, double ey, double six, double siy);
    void draw();
    void action(int uj);
    int ertekret();
    void reset();
};


#endif // AMOBA_H_INCLUDED
