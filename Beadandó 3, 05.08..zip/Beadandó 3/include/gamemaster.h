#ifndef GAMEMASTER_H_INCLUDED
#define GAMEMASTER_H_INCLUDED

#include "graphics.hpp"
#include "amobawid.h"
#include "gombwid.h"


class Jatek
{
private:
    bool player = true;
    bool pvp = true;
    bool menu = true;
    bool endgame = false;
    std::vector<std::vector<Amoba*>> board;
    std::vector<Gomb*> mainmenu;
    std::vector<Gomb*> endmenu;
    int szabadmezok = 225;
public:
    void open();
    void gamestart();
    void valaszt();
    void mezovalt(double ex, double ey, int r);
    void cclear();
    void feltolt(std::vector<Amoba*> oszlop);
    void gameover();
    bool menuret();
    bool endgameret();
    void menudraw();
    void mainclick(double ex, double ey);
    void endclick(double ex, double ey);
    void menufeltolt(Gomb *button, int r);
    void wincheck(int k, int l, int e);
};



#endif // GAMEMASTER_H_INCLUDED
