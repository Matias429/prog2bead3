#ifndef GOMBWID_H_INCLUDED
#define GOMBWID_H_INCLUDED

#include "widget.h"
#include <string>
#include <vector>

class Gomb : public Widget
{
private:
    std::string felirat;
public:
    Gomb(std::string szoveg, double ex, double ey, double six, double siy);
    void draw();
    std::vector<double> koordret();
};

#endif // GOMBWID_H_INCLUDED
