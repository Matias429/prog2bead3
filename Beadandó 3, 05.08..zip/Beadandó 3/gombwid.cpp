#include "widget.h"
#include "gombwid.h"
#include "graphics.hpp"

Gomb::Gomb(std::string szoveg, double ex, double ey, double six, double siy)
{
    x = ex;
    y = ey;
    felirat = szoveg;
    size_x = six;
    size_y = siy;
}

void Gomb::draw()
{
    genv::gout.load_font("LiberationSans-Regular.ttf", 60);
    genv::gout << genv::move_to(x, y) << genv::color(220, 220, 220) << genv::box(size_x, size_y) << genv::move_to(x+size_x/2-genv::gout.twidth(felirat)/2, y+size_y/4) << genv::color(0, 0, 0) << genv::text(felirat) << genv::refresh;
}
std::vector<double> Gomb::koordret()
{
    std::vector<double> tmp;
    tmp.push_back(x);
    tmp.push_back(y);
    tmp.push_back(size_x);
    tmp.push_back(size_y);
    return tmp;
}
